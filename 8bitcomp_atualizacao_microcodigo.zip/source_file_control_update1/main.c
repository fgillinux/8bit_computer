/*
    Gera o arquivo bin�rio para ser
    gravado nas EEPROMs, respons�veis pelo controle e
    decodifica��o autom�tica das intru��es do computador de 8 bits.
    
    F�bio Gil: Dez/2018
    
    Adapta��o da primeira vers�o do Autor: Eng. Wagner Rambo (2017)
    
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "new_instructions.h"


int main(int argc, char *argv[])
{
    FILE *arquivo;
 
    
    #define JC_T2  ((11*8)+3)-1   //Localizacao da Flag JC no tempo T2
    #define JC_T3  ((11*8)+4)-1   //Localizacao da Flag JC no tempo T3
    #define JZ_T2  ((12*8)+3)-1   //Localizacao da Flag JZ no tempo T2
    #define JZ_T3  ((12*8)+4)-1   //Localizacao da Flag JZ no tempo T3
    
    #define JNC_T2  ((27*8)+3)-1   //Localizacao da Flag JNC no tempo T2
    #define JNC_T3  ((27*8)+4)-1   //Localizacao da Flag JNC no tempo T3
    #define JNZ_T2  ((28*8)+3)-1   //Localizacao da Flag JNZ no tempo T2
    #define JNZ_T3  ((28*8)+4)-1   //Localizacao da Flag JNZ no tempo T3
    
    
    //----------------------------------------------------
    // EEPROM 2
    //----------------------------------------------------
    arquivo = fopen("EEPROM2.bin","wb");   
  
    char EEPROM2_TMP[sizeof(EEPROM_2)];
    memcpy(EEPROM2_TMP,EEPROM_2,sizeof(EEPROM_2)); //Salva estado do vetor EEPROM_2
    
    //CF = 0, ZF = 0
    EEPROM_2[JC_T2] = PCI_2;
    EEPROM_2[JZ_T2] = PCI_2;
    EEPROM_2[JNC_T2] = PCO_2|MAI_2;
    EEPROM_2[JNC_T3] = JMP_2|RMO_2;    
    EEPROM_2[JNZ_T2] = PCO_2|MAI_2;
    EEPROM_2[JNZ_T3] = JMP_2|RMO_2;
    fwrite(&EEPROM_2,1,sizeof(EEPROM_2),arquivo);
    memcpy(EEPROM_2,EEPROM2_TMP,sizeof(EEPROM2_TMP)); //Retorna estado original do vetor EEPROM_2

    //CF = 1, ZF = 0
    EEPROM_2[JC_T2] = PCO_2|MAI_2;
    EEPROM_2[JC_T3] = JMP_2|RMO_2;
    EEPROM_2[JZ_T2] = PCI_2;
    EEPROM_2[JNZ_T2] = PCO_2|MAI_2;
    EEPROM_2[JNZ_T3] = JMP_2|RMO_2;
    EEPROM_2[JNC_T2] = PCI_2;
    fwrite(&EEPROM_2,1,sizeof(EEPROM_2),arquivo);
    memcpy(EEPROM_2,EEPROM2_TMP,sizeof(EEPROM2_TMP)); //Retorna estado original do vetor EEPROM_2

    //CF = 0, ZF = 1
    EEPROM_2[JZ_T2] = PCO_2|MAI_2;
    EEPROM_2[JZ_T3] = JMP_2|RMO_2;
    EEPROM_2[JC_T2] = PCI_2;
    EEPROM_2[JNC_T2] = PCO_2|MAI_2;
    EEPROM_2[JNC_T3] = JMP_2|RMO_2;    
    EEPROM_2[JNZ_T2] = PCI_2;
    fwrite(&EEPROM_2,1,sizeof(EEPROM_2),arquivo);
    memcpy(EEPROM_2,EEPROM2_TMP,sizeof(EEPROM2_TMP)); //Retorna estado original do vetor EEPROM_2

    //CF = 1, ZF = 1
    EEPROM_2[JC_T2] = PCO_2|MAI_2;
    EEPROM_2[JC_T3] = JMP_2|RMO_2;
    EEPROM_2[JZ_T2] = PCO_2|MAI_2;
    EEPROM_2[JZ_T3] = JMP_2|RMO_2;
    EEPROM_2[JNC_T2] = PCI_2;
    EEPROM_2[JNZ_T2] = PCI_2;
    fwrite(&EEPROM_2,1,sizeof(EEPROM_2),arquivo);
 
    fclose(arquivo);

    
    //----------------------------------------------------
    // EEPROM 1
    //----------------------------------------------------
       
    arquivo = fopen("EEPROM1.bin","wb");
    
    //CF = 0, ZF = 0
    fwrite(&EEPROM_1,1,sizeof(EEPROM_1),arquivo);
    //CF = 1, ZF = 0
    fwrite(&EEPROM_1,1,sizeof(EEPROM_1),arquivo);
    //CF = 0, ZF = 1
    fwrite(&EEPROM_1,1,sizeof(EEPROM_1),arquivo);
    //CF = 1, ZF = 1
    fwrite(&EEPROM_1,1,sizeof(EEPROM_1),arquivo);
    
    fclose(arquivo);
    
    
    
    //----------------------------------------------------
    // EEPROM 0
    //----------------------------------------------------  
   
    arquivo = fopen("EEPROM0.bin","wb");
    
    //CF = 0, ZF = 0
    fwrite(&EEPROM_0,1,sizeof(EEPROM_0),arquivo);
    //CF = 1, ZF = 0
    fwrite(&EEPROM_0,1,sizeof(EEPROM_0),arquivo);
    //CF = 0, ZF = 1
    fwrite(&EEPROM_0,1,sizeof(EEPROM_0),arquivo);
    //CF = 1, ZF = 1
    fwrite(&EEPROM_0,1,sizeof(EEPROM_0),arquivo);
    
    fclose(arquivo);
   
    printf("Arquivos binarios gerados com sucesso!\n\n");
 
    system("PAUSE");	
    
  return 0;
  
} //end main
























